# pokemon-react-adventure
A pokedex desined with React, just for fun
